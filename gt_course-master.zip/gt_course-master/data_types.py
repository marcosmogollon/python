myInteger = 5
myFloat = 5.1
myString = "Hello"
myBoolean = True
a = myInteger * myFloat
b = myInteger * myString
c = myInteger * myBoolean
#d = myFloat * myString
e = myFloat * myBoolean
f = myString * myBoolean

print(f, e)
