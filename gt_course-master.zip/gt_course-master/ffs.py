

def my_TAs(first_TA, second_TA, third_TA):
    returned_string = str(first_TA) + " " + str(second_TA) + " and " + str(third_TA) + " are awesome!"
    return(returned_string)

test_first_TA = "Joshua"
test_second_TA = "Jackie"
test_third_TA = "Marguerite"
print(my_TAs(test_first_TA, test_second_TA, test_third_TA))
